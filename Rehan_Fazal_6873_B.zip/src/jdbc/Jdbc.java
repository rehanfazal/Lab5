/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jdbc;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.*;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author habid.bscs13seecs
 */
public class Jdbc {
   
    private static String jdbcDriver = "com.mysql.jdbc.Driver";
    private static String dbName = "geo";


    public static void main(String[] args) throws SQLException {
       try {
            //query = "Create table geocity (locid INTEGER not null,country VARCHAR(20),region VARCHAR(20),city VARCHAR(30),postalcode VARCHAR(10),latitude VARCHAR(20),longitude VARCHAR(30),metrocode VARCHAR(20),areacode VARCHAR(20));;";
            readcsv();
        } catch (IOException ex) {
            Logger.getLogger(Jdbc.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public static void readcsv() throws FileNotFoundException, IOException, SQLException {
       
       String csvFile = "c:\\geocity.csv";
         try {
            Class.forName(jdbcDriver);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Jdbc.class.getName()).log(Level.SEVERE, null, ex);
        }
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/?user=root&password=root");
        Statement rs = conn.createStatement();
        try { 
			
        //create BufferedReader to read csv file
       BufferedReader br = new BufferedReader(new FileReader(csvFile));
       String line = "";
       StringTokenizer st = null;

       int lineNumber = 0; 
       int tokenNumber = 0;
       //read comma separated file line by line
       while ((line = br.readLine()) != null) {
         lineNumber++;
         if (lineNumber>2){
         st = new StringTokenizer(line, ",");

        while (st.hasMoreTokens()) {
           tokenNumber++;
           System.out.print(st.nextToken() + "  ");
         }
         }
         System.out.println();
         //reset token number
         tokenNumber = 0;
       }
     } catch (Exception e) {
       System.err.println("CSV file cannot be read : " + e);
     }
   }
    
    public static void select_user(Connection conn) {
        Statement stmt = null;
ResultSet rs = null;

try {
    stmt = conn.createStatement();
    rs = stmt.executeQuery("SELECT foo FROM bar");

    // or alternatively, if you don't know ahead of time that
    // the query will be a SELECT...

    if (stmt.execute("SELECT foo FROM bar")) {
        rs = stmt.getResultSet();
    }

    // Now do something with the ResultSet ....
}
catch (SQLException ex){
    // handle any errors
    System.out.println("SQLException: " + ex.getMessage());
    System.out.println("SQLState: " + ex.getSQLState());
    System.out.println("VendorError: " + ex.getErrorCode());
}
finally {
    // it is a good idea to release
    // resources in a finally{} block
    // in reverse-order of their creation
    // if they are no-longer needed

    if (rs != null) {
        try {
            rs.close();
        } catch (SQLException sqlEx) { } // ignore

        rs = null;
    }

    if (stmt != null) {
        try {
            stmt.close();
        } catch (SQLException sqlEx) { } // ignore

        stmt = null;
    }
}
    }
    
    
    
    
}
